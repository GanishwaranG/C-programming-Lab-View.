#include <stdio.h>
int main()
{
	int n, term;
	printf("the value :");
	scanf("%d",&n);
	for (int i = 0; i <= n; i++)
	{
		int k= i + 1;
		if (k % 2 == 0) {
			term = (k*k) - 2;
			printf("Term sequence value is %d : %d\n", i,term );
		}
		else {
			term = (k*k) - 1;
			printf("Term sequence value is %d : %d\n", i,term );
		}
	}
	return 0;
}