#include <stdio.h>
int main(){
    int a,b,c;
    printf("value 1 :");
    scanf("%d",&a);
    printf("value 2 :");
    scanf("%d",&b);
    printf("value 3 :");
    scanf("%d",&c);
    if (a>c && a>b){
     printf("a is greater value");
    }
    else if (b>a && b>c){
        printf("b is greater value");
    }
    else if (c>a && c>b){
        printf("c is greater value");
    }
    else {
        printf("null");
    }
}